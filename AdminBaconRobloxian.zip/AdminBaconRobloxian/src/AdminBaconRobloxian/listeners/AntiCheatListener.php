<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\listeners;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use AdminBaconRobloxian\Main;

class AntiCheatListener implements Listener {

    private Main $plugin;

    // Track positions before knockback
    /** @var array<string, \pocketmine\math\Vector3> */
    private array $preKnockbackPos = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;

        // Schedule periodic fly + speed check every 2 ticks (not every tick - optimize for low RAM)
        $this->plugin->getScheduler()->scheduleRepeatingTask(
            new ClosureTask(function(): void {
                $this->periodicChecks();
            }),
            2 // every 2 ticks = ~0.1s, lightweight
        );
    }

    /**
     * Periodic checks: fly + speed (runs every 2 ticks)
     */
    private function periodicChecks(): void {
        $acm = $this->plugin->getAntiCheatManager();
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if (!$acm->shouldCheck($player)) continue;
            $acm->checkSpeed($player);
            $acm->checkFly($player);
        }
    }

    /**
     * On player move - additional move validation
     */
    public function onPlayerMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        if (!$this->plugin->getAntiCheatManager()->shouldCheck($player)) return;

        // Additional: if player is flagged for going through blocks (future expansion)
    }

    /**
     * On entity attack - kill aura, reach, auto clicker
     */
    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void {
        $attacker = $event->getDamager();
        if (!($attacker instanceof Player)) return;

        $acm = $this->plugin->getAntiCheatManager();
        if (!$acm->shouldCheck($attacker)) return;

        // Auto clicker check on every hit
        $acm->checkAutoClicker($attacker);

        // Kill aura + reach check if target is player
        $target = $event->getEntity();
        if ($target instanceof Player) {
            $acm->checkKillAura($attacker, $target);
        }
    }

    /**
     * Track position before entity takes damage for knockback check
     */
    public function onEntityDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if (!($entity instanceof Player)) return;
        if (!$this->plugin->getAntiCheatManager()->shouldCheck($entity)) return;

        // Save position before knockback is applied
        $this->preKnockbackPos[$entity->getName()] = $entity->getPosition()->asVector3();

        // Schedule check AFTER knockback is applied (next tick)
        $plugin = $this->plugin;
        $name   = $entity->getName();
        $pos    = $entity->getPosition()->asVector3();

        $plugin->getScheduler()->scheduleDelayedTask(
            new ClosureTask(function() use ($plugin, $name, $pos): void {
                $player = $plugin->getServer()->getPlayerByPrefix($name);
                if ($player !== null && $plugin->getAntiCheatManager()->shouldCheck($player)) {
                    $plugin->getAntiCheatManager()->checkNoKnockback($player, $pos);
                }
            }),
            2 // check after 2 ticks
        );
    }

    /**
     * Block break - X-Ray detection
     */
    public function onBlockBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        if (!$this->plugin->getAntiCheatManager()->shouldCheck($player)) return;

        $block     = $event->getBlock();
        $blockName = strtolower($block->getName());

        // Normalize block name to match config keys
        // PocketMine block names may vary, map common ones
        $blockMap = [
            "diamond ore"           => "diamond_ore",
            "deepslate diamond ore" => "deepslate_diamond_ore",
            "emerald ore"           => "emerald_ore",
            "ancient debris"        => "ancient_debris",
            "gold ore"              => "gold_ore",
            "iron ore"              => "iron_ore",
        ];

        $mappedName = $blockMap[$blockName] ?? str_replace(" ", "_", $blockName);

        $this->plugin->getAntiCheatManager()->checkXRay($player, $mappedName);
    }
}
