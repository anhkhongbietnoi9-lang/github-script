<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\listeners;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\server\CommandEvent;
use AdminBaconRobloxian\Main;

class PlayerListener implements Listener {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    /**
     * Check ban on join, apply permissions
     */
    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $name   = $player->getName();

        // Check ban
        if ($this->plugin->getBanManager()->isBanned($name)) {
            $player->kick("§cBạn đã bị ban khỏi server này!");
            return;
        }

        // Apply permissions
        $this->plugin->getAdminManager()->onPlayerJoin($player);

        // Welcome message for owner
        if ($this->plugin->getAdminManager()->isOwner($player)) {
            $player->sendMessage("§6[Admin] §aChào mừng Owner §e" . $name . " §ađã vào server!");
        } elseif ($this->plugin->getAdminManager()->isAdmin($player)) {
            $player->sendMessage("§6[Admin] §aChào mừng Admin §e" . $name . " §ađã vào server!");
        }
    }

    /**
     * Cleanup on quit
     */
    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $this->plugin->getAntiCheatManager()->cleanupPlayer($player->getName());
    }

    /**
     * Block dangerous commands from non-admin players
     * Chặn /op, /deop, /stop từ player thường
     */
    public function onPlayerCommand(PlayerCommandPreprocessEvent $event): void {
        $player  = $event->getPlayer();
        $message = strtolower(trim($event->getMessage()));

        // Chặn /op và /deop từ non-owner
        if (str_starts_with($message, "/op ") || $message === "/op") {
            if (!$this->plugin->getAdminManager()->isOwner($player)) {
                $event->cancel();
                $player->sendMessage($this->plugin->getMessage("no_permission"));
                $this->plugin->getLogger()->warning("[Security] " . $player->getName() . " tried to use /op");
                return;
            }
        }

        if (str_starts_with($message, "/deop ") || $message === "/deop") {
            if (!$this->plugin->getAdminManager()->isOwner($player)) {
                $event->cancel();
                $player->sendMessage($this->plugin->getMessage("no_permission"));
                return;
            }
        }

        // Chặn /stop server từ non-owner
        if ($message === "/stop") {
            if (!$this->plugin->getAdminManager()->isOwner($player)) {
                $event->cancel();
                $player->sendMessage($this->plugin->getMessage("no_permission"));
                $this->plugin->getLogger()->warning("[Security] " . $player->getName() . " tried to use /stop");
                return;
            }
        }

        // Log bất kỳ lệnh nào từ player thường để theo dõi
        if (!$this->plugin->getAdminManager()->isAdmin($player)) {
            if (str_starts_with($message, "/")) {
                // Chỉ log lệnh admin-like
                $suspicious = ["/gamemode", "/give", "/effect", "/enchant", "/difficulty"];
                foreach ($suspicious as $cmd) {
                    if (str_starts_with($message, $cmd)) {
                        $this->plugin->getLogger()->info("[CmdLog] " . $player->getName() . ": " . $event->getMessage());
                        break;
                    }
                }
            }
        }
    }
}
