<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\managers;

use pocketmine\player\Player;
use pocketmine\permission\Permission;
use pocketmine\permission\PermissionManager;
use AdminBaconRobloxian\Main;

class AdminManager {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function isOwner(Player|string $player): bool {
        $name = ($player instanceof Player) ? $player->getName() : $player;
        return strtolower($name) === strtolower($this->plugin->getOwnerName());
    }

    public function isAdmin(Player|string $player): bool {
        $name = ($player instanceof Player) ? strtolower($player->getName()) : strtolower($player);
        if ($this->isOwner($name)) return true;
        $admins = $this->plugin->getDataConfig()->get("admins", []);
        return in_array($name, array_map('strtolower', $admins), true);
    }

    public function addAdmin(string $playerName): bool {
        if ($this->isOwner($playerName)) return false; // owner không cần thêm
        $admins = $this->plugin->getDataConfig()->get("admins", []);
        $lower = strtolower($playerName);
        if (!in_array($lower, array_map('strtolower', $admins), true)) {
            $admins[] = $lower;
            $this->plugin->getDataConfig()->set("admins", $admins);
            $this->plugin->saveDataConfig();

            // Apply permissions nếu đang online
            $player = $this->plugin->getServer()->getPlayerByPrefix($playerName);
            if ($player !== null) {
                $this->applyAdminPermissions($player);
            }
            return true;
        }
        return false;
    }

    public function removeAdmin(string $playerName): bool {
        $admins = $this->plugin->getDataConfig()->get("admins", []);
        $lower = strtolower($playerName);
        $filtered = array_filter($admins, fn($a) => strtolower($a) !== $lower);
        if (count($filtered) < count($admins)) {
            $this->plugin->getDataConfig()->set("admins", array_values($filtered));
            $this->plugin->saveDataConfig();

            // Revoke permissions nếu đang online
            $player = $this->plugin->getServer()->getPlayerByPrefix($playerName);
            if ($player !== null) {
                $this->revokeAdminPermissions($player);
            }
            return true;
        }
        return false;
    }

    public function applyOwnerPermissions(Player $player): void {
        $attachment = $player->addAttachment($this->plugin);
        $attachment->setPermission("adminbacon.owner", true);
        $attachment->setPermission("adminbacon.admin", true);
        $attachment->setPermission("adminbacon.bypass", true);
        $attachment->setPermission("pocketmine.command.op", false); // Chặn dùng /op
    }

    public function applyAdminPermissions(Player $player): void {
        $attachment = $player->addAttachment($this->plugin);
        $attachment->setPermission("adminbacon.admin", true);
        $attachment->setPermission("adminbacon.bypass", false);
        $attachment->setPermission("pocketmine.command.op", false);
    }

    public function revokeAdminPermissions(Player $player): void {
        // Remove attachments added by this plugin for admin
        foreach ($player->getEffectivePermissions() as $perm) {
            // PocketMine handles removing via attachment
        }
        // Easiest approach: re-login via disconnect is not viable,
        // so we add an attachment that explicitly sets to false
        $attachment = $player->addAttachment($this->plugin);
        $attachment->setPermission("adminbacon.admin", false);
    }

    /**
     * Called on PlayerJoin to restore saved permissions
     */
    public function onPlayerJoin(Player $player): void {
        if ($this->isOwner($player)) {
            $this->applyOwnerPermissions($player);
        } elseif ($this->isAdmin($player)) {
            $this->applyAdminPermissions($player);
        }
    }
}
