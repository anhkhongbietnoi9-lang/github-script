<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\managers;

use pocketmine\player\Player;
use pocketmine\math\Vector3;
use AdminBaconRobloxian\Main;

class AntiCheatManager {

    private Main $plugin;

    // === Player tracking data ===
    /** @var array<string, Vector3> */
    private array $lastPosition = [];

    /** @var array<string, int> */
    private array $airTicks = [];

    /** @var array<string, float> */
    private array $lastAttackTime = [];

    /** @var array<string, int> */
    private array $clickCount = [];

    /** @var array<string, float> */
    private array $clickWindowStart = [];

    /** @var array<string, float> */
    private array $lastKnockbackDistance = [];

    /** @var array<string, int> */
    private array $speedViolations = [];

    /** @var array<string, array> */
    private array $oreLog = []; // xray tracking: [timestamp => count]

    // === Warning system ===
    /** @var array<string, int> */
    private array $warnings = [];

    /** @var array<string, array<string, int>> */
    private array $violationCounts = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        // Load saved warnings
        $saved = $this->plugin->getDataConfig()->get("warnings", []);
        foreach ($saved as $name => $count) {
            $this->warnings[strtolower($name)] = (int)$count;
        }
    }

    // ==========================================
    // BYPASS CHECK
    // ==========================================

    public function shouldCheck(Player $player): bool {
        if (!$this->plugin->getConfig()->getNested("anticheat.enabled", true)) return false;
        if ($this->plugin->getAdminManager()->isOwner($player)) return false;

        // Check custom bypass list
        $bypass = $this->plugin->getDataConfig()->get("anticheat_bypass", []);
        if (in_array(strtolower($player->getName()), array_map('strtolower', $bypass), true)) return false;

        return true;
    }

    public function setBypass(string $playerName, bool $bypass): void {
        $list = $this->plugin->getDataConfig()->get("anticheat_bypass", []);
        $lower = strtolower($playerName);
        if ($bypass) {
            if (!in_array($lower, $list, true)) {
                $list[] = $lower;
            }
        } else {
            $list = array_values(array_filter($list, fn($n) => $n !== $lower));
        }
        $this->plugin->getDataConfig()->set("anticheat_bypass", $list);
        $this->plugin->saveDataConfig();
    }

    // ==========================================
    // SPEED HACK CHECK
    // ==========================================

    public function checkSpeed(Player $player): void {
        if (!$this->plugin->getConfig()->getNested("anticheat.speed.enabled", true)) return;

        $name = $player->getName();
        $pos  = $player->getPosition();

        if (!isset($this->lastPosition[$name])) {
            $this->lastPosition[$name] = $pos->asVector3();
            return;
        }

        $last  = $this->lastPosition[$name];
        $diffX = abs($pos->x - $last->x);
        $diffZ = abs($pos->z - $last->z);
        $dist  = sqrt($diffX ** 2 + $diffZ ** 2);

        $maxSpeed = (float) $this->plugin->getConfig()->getNested("anticheat.speed.max_speed", 0.65);

        if ($dist > $maxSpeed) {
            $this->speedViolations[$name] = ($this->speedViolations[$name] ?? 0) + 1;
            $threshold = (int) $this->plugin->getConfig()->getNested("anticheat.speed.violations_before_warn", 5);

            if ($this->speedViolations[$name] >= $threshold) {
                $this->speedViolations[$name] = 0;
                $this->warn($player, "Speed Hack (dist: " . round($dist, 2) . ")");

                // Teleport back
                $player->teleport($last);
            }
        } else {
            // Reset violations gradually
            if (isset($this->speedViolations[$name]) && $this->speedViolations[$name] > 0) {
                $this->speedViolations[$name]--;
            }
        }

        $this->lastPosition[$name] = $pos->asVector3();
    }

    // ==========================================
    // FLY HACK CHECK
    // ==========================================

    public function checkFly(Player $player): void {
        if (!$this->plugin->getConfig()->getNested("anticheat.fly.enabled", true)) return;
        if ($player->getAllowFlight()) return; // Fly được cấp phép
        if ($player->isCreative() || $player->isSpectator()) return;

        $name = $player->getName();

        // isOnGround() của PocketMine
        if (!$player->isOnGround() && !$player->isUnderwater()) {
            $this->airTicks[$name] = ($this->airTicks[$name] ?? 0) + 1;
            $maxAir = (int) $this->plugin->getConfig()->getNested("anticheat.fly.max_air_ticks", 20);

            if ($this->airTicks[$name] > $maxAir) {
                $this->airTicks[$name] = 0;
                $this->warn($player, "Fly Hack (air ticks: " . $this->airTicks[$name] . ")");
            }
        } else {
            $this->airTicks[$name] = 0;
        }
    }

    // ==========================================
    // REACH HACK CHECK
    // ==========================================

    public function checkReach(Player $player, Player $target): void {
        if (!$this->plugin->getConfig()->getNested("anticheat.reach.enabled", true)) return;

        $dist = $player->getPosition()->distance($target->getPosition());
        $maxReach = (float) $this->plugin->getConfig()->getNested("anticheat.reach.max_reach", 3.5);

        if ($dist > $maxReach) {
            $this->warn($player, "Reach Hack (dist: " . round($dist, 2) . ")");
        }
    }

    // ==========================================
    // KILL AURA CHECK
    // ==========================================

    public function checkKillAura(Player $player, Player $target): void {
        if (!$this->plugin->getConfig()->getNested("anticheat.killaura.enabled", true)) return;

        $maxAngle = (float) $this->plugin->getConfig()->getNested("anticheat.killaura.max_attack_angle", 90);

        // Tính góc giữa hướng nhìn của player và hướng đến target
        $dir   = $player->getDirectionVector();
        $toTarget = $target->getPosition()->subtractVector($player->getPosition())->normalize();

        // Dot product để tính góc
        $dot = ($dir->x * $toTarget->x) + ($dir->y * $toTarget->y) + ($dir->z * $toTarget->z);
        $dot = max(-1.0, min(1.0, $dot));
        $angle = rad2deg(acos($dot));

        if ($angle > $maxAngle) {
            $this->warn($player, "Kill Aura (angle: " . round($angle, 1) . "°)");
        }

        // Also check reach
        $this->checkReach($player, $target);
    }

    // ==========================================
    // AUTO CLICKER CHECK
    // ==========================================

    public function checkAutoClicker(Player $player): void {
        if (!$this->plugin->getConfig()->getNested("anticheat.autoclicker.enabled", true)) return;

        $name = $player->getName();
        $now  = microtime(true);

        if (!isset($this->clickWindowStart[$name])) {
            $this->clickWindowStart[$name] = $now;
            $this->clickCount[$name] = 0;
        }

        $this->clickCount[$name]++;

        $elapsed = $now - $this->clickWindowStart[$name];

        if ($elapsed >= 1.0) {
            $cps = $this->clickCount[$name] / $elapsed;
            $maxCps = (int) $this->plugin->getConfig()->getNested("anticheat.autoclicker.max_cps", 16);

            if ($cps > $maxCps) {
                $this->warn($player, "Auto Clicker (CPS: " . round($cps, 1) . ")");
            }

            // Reset window
            $this->clickWindowStart[$name] = $now;
            $this->clickCount[$name] = 0;
        }
    }

    // ==========================================
    // NO KNOCKBACK CHECK
    // ==========================================

    public function recordKnockback(Player $player, float $distance): void {
        $this->lastKnockbackDistance[$player->getName()] = $distance;
    }

    public function checkNoKnockback(Player $player, Vector3 $posBefore): void {
        if (!$this->plugin->getConfig()->getNested("anticheat.noknockback.enabled", true)) return;

        $posAfter = $player->getPosition()->asVector3();
        $dist = $posBefore->distance($posAfter);

        $minKb = (float) $this->plugin->getConfig()->getNested("anticheat.noknockback.min_knockback_distance", 0.08);

        if ($dist < $minKb) {
            $this->warn($player, "No Knockback (moved: " . round($dist, 3) . ")");
        }
    }

    // ==========================================
    // X-RAY CHECK
    // ==========================================

    public function checkXRay(Player $player, string $blockName): void {
        if (!$this->plugin->getConfig()->getNested("anticheat.xray.enabled", true)) return;

        $trackedBlocks = $this->plugin->getConfig()->getNested("anticheat.xray.tracked_blocks", []);
        if (!in_array($blockName, $trackedBlocks, true)) return;

        $name = strtolower($player->getName());
        $now  = time();

        if (!isset($this->oreLog[$name])) {
            $this->oreLog[$name] = [];
        }

        // Add timestamp
        $this->oreLog[$name][] = $now;

        // Cleanup old entries
        $window = (int) $this->plugin->getConfig()->getNested("anticheat.xray.ore_time_window", 60);
        $this->oreLog[$name] = array_filter(
            $this->oreLog[$name],
            fn($t) => ($now - $t) <= $window
        );

        $count = count($this->oreLog[$name]);
        $threshold = (int) $this->plugin->getConfig()->getNested("anticheat.xray.ore_threshold", 15);

        if ($count >= $threshold) {
            $this->warn($player, "X-Ray Suspected ({$count} ore blocks in {$window}s)");
            $this->logSuspect($player, "X-Ray: {$blockName}, count={$count}");
            // Reset log sau khi cảnh cáo
            $this->oreLog[$name] = [];
        }
    }

    // ==========================================
    // WARNING SYSTEM
    // ==========================================

    public function warn(Player $player, string $reason): void {
        $name = strtolower($player->getName());
        $this->warnings[$name] = ($this->warnings[$name] ?? 0) + 1;
        $count = $this->warnings[$name];
        $max   = (int) $this->plugin->getConfig()->getNested("anticheat.max_warnings", 3);

        // Save warnings
        $saved = $this->plugin->getDataConfig()->get("warnings", []);
        $saved[$name] = $count;
        $this->plugin->getDataConfig()->set("warnings", $saved);
        $this->plugin->saveDataConfig();

        // Log to console
        $this->logSuspect($player, $reason);

        // Notify player
        $msg = $this->plugin->getMessage("warn", [
            "reason" => $reason,
            "count"  => $count,
            "max"    => $max
        ]);
        $player->sendMessage($msg);

        // Notify all admins + owner
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
            if ($this->plugin->getAdminManager()->isAdmin($p) || $this->plugin->getAdminManager()->isOwner($p)) {
                $p->sendMessage("§c[AntiCheat] §e" . $player->getName() . " §cvị phạm: §f" . $reason . " §7(Cảnh cáo: {$count}/{$max})");
            }
        }

        // Action on max warnings
        if ($count >= $max) {
            $this->warnings[$name] = 0;
            $saved[$name] = 0;
            $this->plugin->getDataConfig()->set("warnings", $saved);
            $this->plugin->saveDataConfig();

            $autoBan = (bool) $this->plugin->getConfig()->getNested("anticheat.auto_ban_after_kick", false);
            if ($autoBan) {
                $banReason = $this->plugin->getMessage("ban_reason");
                $this->plugin->getBanManager()->ban($player->getName(), $banReason);
                $this->plugin->getLogger()->warning("[AntiCheat] AUTO BAN: " . $player->getName() . " - " . $reason);
            } else {
                $kickReason = $this->plugin->getMessage("kick_reason", ["reason" => $reason]);
                $player->kick($kickReason);
                $this->plugin->getLogger()->warning("[AntiCheat] KICK: " . $player->getName() . " - " . $reason);
            }
        }
    }

    public function getWarnings(string $playerName): int {
        return $this->warnings[strtolower($playerName)] ?? 0;
    }

    public function clearWarnings(string $playerName): void {
        $lower = strtolower($playerName);
        $this->warnings[$lower] = 0;
        $saved = $this->plugin->getDataConfig()->get("warnings", []);
        $saved[$lower] = 0;
        $this->plugin->getDataConfig()->set("warnings", $saved);
        $this->plugin->saveDataConfig();
    }

    // ==========================================
    // LOGGING
    // ==========================================

    private function logSuspect(Player $player, string $reason): void {
        $logEnabled = (bool) $this->plugin->getConfig()->getNested("logging.log_violations", true);
        if (!$logEnabled) return;

        $msg = "[AntiCheat][" . date("Y-m-d H:i:s") . "] " . $player->getName()
            . " | " . $player->getNetworkSession()->getIp()
            . " | " . $reason;

        $this->plugin->getLogger()->warning($msg);

        $logFile = (bool) $this->plugin->getConfig()->getNested("logging.log_to_file", true);
        if ($logFile) {
            $filePath = $this->plugin->getDataFolder()
                . $this->plugin->getConfig()->getNested("logging.log_file", "anticheat_log.txt");
            file_put_contents($filePath, $msg . PHP_EOL, FILE_APPEND);
        }
    }

    // ==========================================
    // CLEANUP on player quit
    // ==========================================

    public function cleanupPlayer(string $playerName): void {
        $name = strtolower($playerName);
        unset(
            $this->lastPosition[$name],
            $this->airTicks[$name],
            $this->lastAttackTime[$name],
            $this->clickCount[$name],
            $this->clickWindowStart[$name],
            $this->lastKnockbackDistance[$name],
            $this->speedViolations[$name]
        );
        // Keep oreLog and warnings (persistent)
    }
}
