<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\managers;

use pocketmine\player\Player;
use AdminBaconRobloxian\Main;

class BanManager {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function isBanned(string $playerName): bool {
        $banned = $this->plugin->getDataConfig()->get("banned", []);
        return in_array(strtolower($playerName), array_map('strtolower', $banned), true);
    }

    public function ban(string $playerName, string $reason = "Vi phạm server"): void {
        $banned = $this->plugin->getDataConfig()->get("banned", []);
        $lower = strtolower($playerName);
        if (!in_array($lower, array_map('strtolower', $banned), true)) {
            $banned[] = $lower;
            $this->plugin->getDataConfig()->set("banned", $banned);
            $this->plugin->saveDataConfig();
        }

        // Kick nếu đang online
        $player = $this->plugin->getServer()->getPlayerByPrefix($playerName);
        if ($player !== null) {
            $player->kick("§cBạn đã bị ban: " . $reason);
        }
    }

    public function unban(string $playerName): bool {
        $banned = $this->plugin->getDataConfig()->get("banned", []);
        $lower = strtolower($playerName);
        $filtered = array_filter($banned, fn($b) => strtolower($b) !== $lower);
        if (count($filtered) < count($banned)) {
            $this->plugin->getDataConfig()->set("banned", array_values($filtered));
            $this->plugin->saveDataConfig();
            return true;
        }
        return false;
    }

    public function getBannedList(): array {
        return $this->plugin->getDataConfig()->get("banned", []);
    }
}
