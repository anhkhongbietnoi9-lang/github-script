<?php

declare(strict_types=1);

namespace AdminBaconRobloxian;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\Config;

use AdminBaconRobloxian\commands\BanCommand;
use AdminBaconRobloxian\commands\KickCommand;
use AdminBaconRobloxian\commands\FlyCommand;
use AdminBaconRobloxian\commands\VanishCommand;
use AdminBaconRobloxian\commands\GodCommand;
use AdminBaconRobloxian\commands\InvseeCommand;
use AdminBaconRobloxian\commands\AddAdminCommand;
use AdminBaconRobloxian\commands\RemoveAdminCommand;
use AdminBaconRobloxian\commands\WarningsCommand;
use AdminBaconRobloxian\commands\ClearWarningsCommand;
use AdminBaconRobloxian\commands\AntiCheatCommand;
use AdminBaconRobloxian\listeners\PlayerListener;
use AdminBaconRobloxian\listeners\AntiCheatListener;
use AdminBaconRobloxian\managers\AdminManager;
use AdminBaconRobloxian\managers\AntiCheatManager;
use AdminBaconRobloxian\managers\BanManager;

class Main extends PluginBase {

    private static Main $instance;

    private AdminManager $adminManager;
    private AntiCheatManager $antiCheatManager;
    private BanManager $banManager;

    private Config $dataConfig;

    public static function getInstance(): Main {
        return self::$instance;
    }

    protected function onEnable(): void {
        self::$instance = $this;

        // Save default config
        $this->saveDefaultConfig();

        // Save default config.yml
        if (!file_exists($this->getDataFolder() . "config.yml")) {
            $this->saveResource("config.yml");
        }

        // Reload config
        $this->reloadConfig();

        // Init data config (lưu admins, bans, warnings)
        $this->dataConfig = new Config($this->getDataFolder() . "data.yml", Config::YAML, [
            "admins" => [],
            "banned" => [],
            "warnings" => [],
            "anticheat_bypass" => []
        ]);

        // Init managers
        $this->adminManager    = new AdminManager($this);
        $this->banManager      = new BanManager($this);
        $this->antiCheatManager = new AntiCheatManager($this);

        // Register commands
        $this->registerCommands();

        // Register listeners
        $this->getServer()->getPluginManager()->registerEvents(new PlayerListener($this), $this);
        $this->getServer()->getPluginManager()->registerEvents(new AntiCheatListener($this), $this);

        // Grant owner permission on startup if online
        $this->grantOwnerPermission();

        $this->getLogger()->info("§aAdminBaconRobloxian đã được bật! Owner: §e" . $this->getOwnerName());
    }

    protected function onDisable(): void {
        // Save data
        if (isset($this->dataConfig)) {
            $this->dataConfig->save();
        }
        $this->getLogger()->info("§cAdminBaconRobloxian đã tắt.");
    }

    private function registerCommands(): void {
        $map = $this->getServer()->getCommandMap();
        $map->register("adminbacon", new BanCommand($this));
        $map->register("adminbacon", new KickCommand($this));
        $map->register("adminbacon", new FlyCommand($this));
        $map->register("adminbacon", new VanishCommand($this));
        $map->register("adminbacon", new GodCommand($this));
        $map->register("adminbacon", new InvseeCommand($this));
        $map->register("adminbacon", new AddAdminCommand($this));
        $map->register("adminbacon", new RemoveAdminCommand($this));
        $map->register("adminbacon", new WarningsCommand($this));
        $map->register("adminbacon", new ClearWarningsCommand($this));
        $map->register("adminbacon", new AntiCheatCommand($this));
    }

    private function grantOwnerPermission(): void {
        $ownerName = $this->getOwnerName();
        $player = $this->getServer()->getPlayerByPrefix($ownerName);
        if ($player !== null) {
            $this->adminManager->applyOwnerPermissions($player);
        }
    }

    // ===== Getters =====

    public function getOwnerName(): string {
        return (string) $this->getConfig()->get("owner", "BaconRobloxian");
    }

    public function getAdminManager(): AdminManager {
        return $this->adminManager;
    }

    public function getAntiCheatManager(): AntiCheatManager {
        return $this->antiCheatManager;
    }

    public function getBanManager(): BanManager {
        return $this->banManager;
    }

    public function getDataConfig(): Config {
        return $this->dataConfig;
    }

    public function saveDataConfig(): void {
        $this->dataConfig->save();
    }

    /**
     * Format màu sắc tin nhắn từ config
     */
    public function getMessage(string $key, array $replacements = []): string {
        $messages = $this->getConfig()->get("messages", []);
        $msg = $messages[$key] ?? $key;
        foreach ($replacements as $placeholder => $value) {
            $msg = str_replace('{' . $placeholder . '}', (string)$value, $msg);
        }
        return $this->colorize($msg);
    }

    public function colorize(string $msg): string {
        return str_replace("&", "§", $msg);
    }
}
