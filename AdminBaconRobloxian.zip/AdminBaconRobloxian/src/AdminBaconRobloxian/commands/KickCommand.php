<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\CommandSender;
use AdminBaconRobloxian\Main;

class KickCommand extends BaseAdminCommand {

    public function __construct(Main $plugin) {
        parent::__construct($plugin, "kick", "Kick người chơi khỏi server", "/kick <player> [reason]");
        $this->setPermission("adminbacon.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->checkAdmin($sender)) return true;
        if (count($args) < 1) {
            $sender->sendMessage("§cCách dùng: /kick <player> [reason]");
            return true;
        }

        $target = $this->getTargetPlayer($sender, $args[0]);
        if ($target === null) return true;
        if (!$this->canTargetPlayer($sender, $target)) return true;

        $reason = count($args) > 1 ? implode(" ", array_slice($args, 1)) : "Bị kick bởi admin";
        $target->kick("§c" . $reason);
        $sender->sendMessage("§aĐã kick §e" . $target->getName() . "§a. Lý do: §f" . $reason);
        $this->plugin->getLogger()->info("[Admin] " . $sender->getName() . " đã kick " . $target->getName());
        return true;
    }
}
