<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\CommandSender;
use AdminBaconRobloxian\Main;

class WarningsCommand extends BaseAdminCommand {

    public function __construct(Main $plugin) {
        parent::__construct($plugin, "warnings", "Xem cảnh cáo anti-cheat của người chơi", "/warnings <player>");
        $this->setPermission("adminbacon.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->checkAdmin($sender)) return true;
        if (count($args) < 1) {
            $sender->sendMessage("§cCách dùng: /warnings <player>");
            return true;
        }

        $targetName = $args[0];
        $count = $this->plugin->getAntiCheatManager()->getWarnings($targetName);
        $max   = (int) $this->plugin->getConfig()->getNested("anticheat.max_warnings", 3);
        $sender->sendMessage("§6[AntiCheat] §e" . $targetName . " §f- Cảnh cáo: §c" . $count . "§f/§c" . $max);
        return true;
    }
}
