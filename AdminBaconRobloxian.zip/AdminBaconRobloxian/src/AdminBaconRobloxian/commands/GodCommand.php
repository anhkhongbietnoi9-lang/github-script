<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use AdminBaconRobloxian\Main;

class GodCommand extends BaseAdminCommand {

    /** @var array<string, bool> */
    private static array $godState = [];

    public function __construct(Main $plugin) {
        parent::__construct($plugin, "god", "Bật/tắt chế độ bất tử", "/god [player]");
        $this->setPermission("adminbacon.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->checkAdmin($sender)) return true;

        if (count($args) >= 1) {
            $target = $this->getTargetPlayer($sender, $args[0]);
            if ($target === null) return true;
            if (!$this->canTargetPlayer($sender, $target)) return true;
            $this->toggleGod($target, $sender);
        } else {
            if (!$this->checkSenderIsPlayer($sender)) return true;
            /** @var Player $sender */
            $this->toggleGod($sender, $sender);
        }
        return true;
    }

    private function toggleGod(Player $target, CommandSender $sender): void {
        $name     = $target->getName();
        $current  = self::$godState[$name] ?? false;
        $newState = !$current;
        self::$godState[$name] = $newState;

        // PocketMine: set invulnerable via setInvulnerable
        $target->setInvulnerable($newState);

        $stateStr = $newState ? "§aBẬT" : "§cTẮT";
        $target->sendMessage("§6[God] §fChế độ bất tử: " . $stateStr);
        if ($sender !== $target) {
            $sender->sendMessage("§aĐã " . ($newState ? "bật" : "tắt") . " god cho §e" . $name);
        }
    }

    public static function isGod(string $playerName): bool {
        return self::$godState[strtolower($playerName)] ?? false;
    }
}
