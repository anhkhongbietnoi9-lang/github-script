<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use AdminBaconRobloxian\Main;

class BanCommand extends BaseAdminCommand {

    public function __construct(Main $plugin) {
        parent::__construct($plugin, "ban", "Ban một người chơi", "/ban <player> [reason]");
        $this->setPermission("adminbacon.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->checkAdmin($sender)) return true;
        if (count($args) < 1) {
            $sender->sendMessage("§cCách dùng: /ban <player> [reason]");
            return true;
        }

        $targetName = $args[0];
        $reason = count($args) > 1 ? implode(" ", array_slice($args, 1)) : "Vi phạm quy định server";

        // Check if target is owner
        if ($this->plugin->getAdminManager()->isOwner($targetName)) {
            if ($sender instanceof Player && !$this->plugin->getAdminManager()->isOwner($sender)) {
                $sender->sendMessage($this->plugin->getMessage("cannot_target_owner"));
                return true;
            }
        }

        if ($this->plugin->getBanManager()->isBanned($targetName)) {
            $sender->sendMessage("§e" . $targetName . " §cđã bị ban trước đó.");
            return true;
        }

        $this->plugin->getBanManager()->ban($targetName, $reason);
        $sender->sendMessage("§a" . $targetName . " đã bị ban. Lý do: §f" . $reason);
        $this->plugin->getLogger()->warning("[Admin] " . $sender->getName() . " đã ban " . $targetName . ". Lý do: " . $reason);
        return true;
    }
}
