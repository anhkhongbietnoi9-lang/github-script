<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use AdminBaconRobloxian\Main;

abstract class BaseAdminCommand extends Command {

    protected Main $plugin;

    public function __construct(Main $plugin, string $name, string $description, string $usage, array $aliases = []) {
        parent::__construct($name, $description, $usage, $aliases);
        $this->plugin = $plugin;
    }

    /**
     * Check if sender is a player with required permission
     */
    protected function checkSenderIsPlayer(CommandSender $sender): bool {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cLệnh này chỉ dùng được trong game!");
            return false;
        }
        return true;
    }

    /**
     * Check if sender has admin permission
     */
    protected function checkAdmin(CommandSender $sender): bool {
        if (!($sender instanceof Player)) {
            // Console always allowed
            return true;
        }
        if (!$this->plugin->getAdminManager()->isAdmin($sender)) {
            $sender->sendMessage($this->plugin->getMessage("no_permission"));
            return false;
        }
        return true;
    }

    /**
     * Check if sender is owner
     */
    protected function checkOwner(CommandSender $sender): bool {
        if (!($sender instanceof Player)) {
            return true; // console
        }
        if (!$this->plugin->getAdminManager()->isOwner($sender)) {
            $sender->sendMessage($this->plugin->getMessage("no_permission"));
            return false;
        }
        return true;
    }

    /**
     * Get player by name, send error if not found
     */
    protected function getTargetPlayer(CommandSender $sender, string $name): ?Player {
        $target = $this->plugin->getServer()->getPlayerByPrefix($name);
        if ($target === null) {
            $sender->sendMessage($this->plugin->getMessage("player_not_found", ["player" => $name]));
        }
        return $target;
    }

    /**
     * Check that target is not owner when called by non-owner
     */
    protected function canTargetPlayer(CommandSender $sender, Player $target): bool {
        if ($this->plugin->getAdminManager()->isOwner($target)) {
            if ($sender instanceof Player && !$this->plugin->getAdminManager()->isOwner($sender)) {
                $sender->sendMessage($this->plugin->getMessage("cannot_target_owner"));
                return false;
            }
        }
        return true;
    }
}
