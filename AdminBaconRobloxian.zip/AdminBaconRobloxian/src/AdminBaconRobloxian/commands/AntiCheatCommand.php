<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\CommandSender;
use AdminBaconRobloxian\Main;

class AntiCheatCommand extends BaseAdminCommand {

    public function __construct(Main $plugin) {
        parent::__construct($plugin, "anticheat", "Bật/tắt anti-cheat cho người chơi", "/anticheat <on|off> <player>");
        $this->setPermission("adminbacon.owner");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->checkOwner($sender)) return true;

        if (count($args) < 2) {
            $sender->sendMessage("§cCách dùng: /anticheat <on|off> <player>");
            return true;
        }

        $toggle     = strtolower($args[0]);
        $targetName = $args[1];

        if (!in_array($toggle, ["on", "off"], true)) {
            $sender->sendMessage("§cGiá trị phải là §fon §choặc §foff");
            return true;
        }

        $bypass = ($toggle === "off");
        $this->plugin->getAntiCheatManager()->setBypass($targetName, $bypass);

        $stateStr = $bypass ? "§cTẮT" : "§aBẬT";
        $sender->sendMessage("§6[AntiCheat] §fAnti-cheat cho §e" . $targetName . "§f: " . $stateStr);

        $player = $this->plugin->getServer()->getPlayerByPrefix($targetName);
        if ($player !== null) {
            $player->sendMessage("§6[AntiCheat] §fAnti-cheat của bạn đã được " . ($bypass ? "§ctắt" : "§abật") . " bởi §e" . $sender->getName());
        }
        return true;
    }
}
