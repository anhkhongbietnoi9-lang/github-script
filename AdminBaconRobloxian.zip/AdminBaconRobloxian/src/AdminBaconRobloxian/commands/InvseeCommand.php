<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\Item;
use AdminBaconRobloxian\Main;

class InvseeCommand extends BaseAdminCommand {

    public function __construct(Main $plugin) {
        parent::__construct($plugin, "invsee", "Xem inventory của người chơi", "/invsee <player>");
        $this->setPermission("adminbacon.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->checkAdmin($sender)) return true;
        if (!$this->checkSenderIsPlayer($sender)) return true;

        if (count($args) < 1) {
            $sender->sendMessage("§cCách dùng: /invsee <player>");
            return true;
        }

        $target = $this->getTargetPlayer($sender, $args[0]);
        if ($target === null) return true;

        /** @var Player $sender */
        $inv = $target->getInventory()->getContents();

        if (empty($inv)) {
            $sender->sendMessage("§e" . $target->getName() . " §fkhông có đồ trong túi.");
            return true;
        }

        $sender->sendMessage("§6=== Inventory của §e" . $target->getName() . " §6===");
        foreach ($inv as $slot => $item) {
            /** @var Item $item */
            $sender->sendMessage("§7Slot §f" . $slot . "§7: §a" . $item->getName()
                . " §7x§f" . $item->getCount()
                . ($item->hasNamedTag() ? " §c[NBT]" : ""));
        }

        // Armor
        $armor = $target->getArmorInventory()->getContents();
        if (!empty($armor)) {
            $sender->sendMessage("§6--- Giáp ---");
            $armorSlots = [0 => "Mũ", 1 => "Áo", 2 => "Quần", 3 => "Giày"];
            foreach ($armor as $slot => $item) {
                $sender->sendMessage("§7" . ($armorSlots[$slot] ?? $slot) . "§7: §a" . $item->getName());
            }
        }

        // Offhand
        $offhand = $target->getOffHandInventory()->getItem(0);
        if (!$offhand->isNull()) {
            $sender->sendMessage("§6--- Tay phụ: §a" . $offhand->getName() . " §7x§f" . $offhand->getCount());
        }

        return true;
    }
}
