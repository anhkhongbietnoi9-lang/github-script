<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\CommandSender;
use AdminBaconRobloxian\Main;

class ClearWarningsCommand extends BaseAdminCommand {

    public function __construct(Main $plugin) {
        parent::__construct($plugin, "clearwarnings", "Xóa cảnh cáo của người chơi", "/clearwarnings <player>");
        $this->setPermission("adminbacon.owner");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->checkOwner($sender)) return true;
        if (count($args) < 1) {
            $sender->sendMessage("§cCách dùng: /clearwarnings <player>");
            return true;
        }

        $targetName = $args[0];
        $this->plugin->getAntiCheatManager()->clearWarnings($targetName);
        $sender->sendMessage("§aĐã xóa tất cả cảnh cáo của §e" . $targetName);
        return true;
    }
}
