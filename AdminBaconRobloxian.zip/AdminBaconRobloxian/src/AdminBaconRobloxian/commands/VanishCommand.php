<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use AdminBaconRobloxian\Main;

class VanishCommand extends BaseAdminCommand {

    /** @var array<string, bool> */
    private static array $vanishState = [];

    public function __construct(Main $plugin) {
        parent::__construct($plugin, "vanish", "Ẩn/hiện khỏi danh sách người chơi", "/vanish [player]");
        $this->setPermission("adminbacon.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->checkAdmin($sender)) return true;

        if (count($args) >= 1) {
            $target = $this->getTargetPlayer($sender, $args[0]);
            if ($target === null) return true;
            if (!$this->canTargetPlayer($sender, $target)) return true;
            $this->toggleVanish($target, $sender);
        } else {
            if (!$this->checkSenderIsPlayer($sender)) return true;
            /** @var Player $sender */
            $this->toggleVanish($sender, $sender);
        }
        return true;
    }

    private function toggleVanish(Player $target, CommandSender $sender): void {
        $name     = $target->getName();
        $current  = self::$vanishState[$name] ?? false;
        $newState = !$current;
        self::$vanishState[$name] = $newState;

        if ($newState) {
            // Hide from all non-admin players
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                if (!$this->plugin->getAdminManager()->isAdmin($p) && $p !== $target) {
                    $p->hidePlayer($target);
                }
            }
            $target->sendMessage("§6[Vanish] §aBạn đã ẩn khỏi các người chơi.");
        } else {
            // Show to all players
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                $p->showPlayer($target);
            }
            $target->sendMessage("§6[Vanish] §cBạn đã hiện ra.");
        }

        if ($sender !== $target) {
            $sender->sendMessage("§aĐã " . ($newState ? "ẩn" : "hiện") . " §e" . $name);
        }
    }

    public static function isVanished(string $playerName): bool {
        return self::$vanishState[strtolower($playerName)] ?? false;
    }
}
