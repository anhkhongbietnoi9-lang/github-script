<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use AdminBaconRobloxian\Main;

class FlyCommand extends BaseAdminCommand {

    /** @var array<string, bool> */
    private static array $flyState = [];

    public function __construct(Main $plugin) {
        parent::__construct($plugin, "fly", "Bật/tắt bay", "/fly [player]");
        $this->setPermission("adminbacon.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->checkAdmin($sender)) return true;

        if (count($args) >= 1) {
            // Toggle fly for another player
            $target = $this->getTargetPlayer($sender, $args[0]);
            if ($target === null) return true;
            if (!$this->canTargetPlayer($sender, $target)) return true;
            $this->toggleFly($target, $sender);
        } else {
            // Toggle fly for self (must be in-game)
            if (!$this->checkSenderIsPlayer($sender)) return true;
            /** @var Player $sender */
            $this->toggleFly($sender, $sender);
        }
        return true;
    }

    private function toggleFly(Player $target, CommandSender $sender): void {
        $name    = $target->getName();
        $current = self::$flyState[$name] ?? $target->getAllowFlight();
        $newState = !$current;
        self::$flyState[$name] = $newState;
        $target->setAllowFlight($newState);

        if (!$newState) {
            $target->setFlying(false);
        }

        $stateStr = $newState ? "§aBẬT" : "§cTẮT";
        $target->sendMessage("§6[Admin] §fChế độ bay: " . $stateStr);
        if ($sender !== $target) {
            $sender->sendMessage("§aĐã " . ($newState ? "bật" : "tắt") . " fly cho §e" . $name);
        }
    }
}
