<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\CommandSender;
use AdminBaconRobloxian\Main;

class AddAdminCommand extends BaseAdminCommand {

    public function __construct(Main $plugin) {
        parent::__construct($plugin, "addadmin", "Cấp quyền admin cho người chơi", "/addadmin <player>");
        $this->setPermission("adminbacon.owner");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->checkOwner($sender)) return true;
        if (count($args) < 1) {
            $sender->sendMessage("§cCách dùng: /addadmin <player>");
            return true;
        }

        $targetName = $args[0];

        if ($this->plugin->getAdminManager()->isOwner($targetName)) {
            $sender->sendMessage("§eOwner không cần cấp admin!");
            return true;
        }

        if ($this->plugin->getAdminManager()->isAdmin($targetName)) {
            $sender->sendMessage("§e" . $targetName . " §fđã là admin.");
            return true;
        }

        $this->plugin->getAdminManager()->addAdmin($targetName);
        $sender->sendMessage("§aĐã cấp quyền admin cho §e" . $targetName);

        $player = $this->plugin->getServer()->getPlayerByPrefix($targetName);
        if ($player !== null) {
            $player->sendMessage("§6[Admin] §aBạn đã được cấp quyền admin bởi §e" . $sender->getName());
        }
        return true;
    }
}
