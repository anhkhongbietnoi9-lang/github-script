<?php

declare(strict_types=1);

namespace AdminBaconRobloxian\commands;

use pocketmine\command\CommandSender;
use AdminBaconRobloxian\Main;

class RemoveAdminCommand extends BaseAdminCommand {

    public function __construct(Main $plugin) {
        parent::__construct($plugin, "removeadmin", "Thu hồi quyền admin", "/removeadmin <player>");
        $this->setPermission("adminbacon.owner");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->checkOwner($sender)) return true;
        if (count($args) < 1) {
            $sender->sendMessage("§cCách dùng: /removeadmin <player>");
            return true;
        }

        $targetName = $args[0];

        if ($this->plugin->getAdminManager()->isOwner($targetName)) {
            $sender->sendMessage("§cKhông thể thu hồi quyền của Owner!");
            return true;
        }

        if (!$this->plugin->getAdminManager()->isAdmin($targetName)) {
            $sender->sendMessage("§e" . $targetName . " §fkhông phải admin.");
            return true;
        }

        $this->plugin->getAdminManager()->removeAdmin($targetName);
        $sender->sendMessage("§aĐã thu hồi quyền admin của §e" . $targetName);

        $player = $this->plugin->getServer()->getPlayerByPrefix($targetName);
        if ($player !== null) {
            $player->sendMessage("§c[Admin] Quyền admin của bạn đã bị thu hồi bởi §e" . $sender->getName());
        }
        return true;
    }
}
