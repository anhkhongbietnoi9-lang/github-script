<?php
declare(strict_types=1);

namespace AntiXray;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\player\Player;
use pocketmine\block\VanillaBlocks;
use pocketmine\scheduler\ClosureTask;

class Main extends PluginBase implements Listener {

    // Ore block IDs to track
    private const ORE_BLOCKS = [
        "diamond_ore", "diamond", "emerald_ore", "emerald",
        "gold_ore", "gold", "iron_ore", "iron",
        "ancient_debris"
    ];

    private const PRECIOUS_ORES = [
        "diamond_ore", "diamond", "emerald_ore", "emerald", "ancient_debris"
    ];

    // Ratio thresholds: precious ores per total blocks mined
    private const SUSPICIOUS_RATIO = 0.15;   // 15% precious = suspicious
    private const BAN_RATIO = 0.30;           // 30% = ban
    private const MIN_BLOCKS_TO_CHECK = 50;   // Don't check until 50 blocks mined

    /** @var array<string, MiningData> */
    private array $miningData = [];

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("§aAntiXray enabled.");

        // Reset daily data
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            foreach ($this->miningData as $name => $data) {
                // Reset counter every ~10 min to not punish sustained mining
                if ($data->getSessionTime() > 600) {
                    $data->resetSession();
                }
            }
        }), 12000);
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $name = $event->getPlayer()->getName();
        $this->miningData[$name] = new MiningData();
    }

    public function onQuit(PlayerQuitEvent $event): void {
        unset($this->miningData[$event->getPlayer()->getName()]);
    }

    public function onBlockBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $name = $player->getName();

        if ($player->hasPermission("anticheat.bypass")) return;

        $data = $this->miningData[$name] ?? null;
        if ($data === null) return;

        $blockName = strtolower($block->getName());

        // Count stone/general blocks
        $isOre = false;
        $isPrecious = false;

        foreach (self::ORE_BLOCKS as $oreName) {
            if (str_contains($blockName, $oreName)) {
                $isOre = true;
                break;
            }
        }

        foreach (self::PRECIOUS_ORES as $oreName) {
            if (str_contains($blockName, $oreName)) {
                $isPrecious = true;
                break;
            }
        }

        $data->addBlock($isPrecious, $isOre);

        $total = $data->getTotalBlocks();
        if ($total < self::MIN_BLOCKS_TO_CHECK) return;

        $ratio = $data->getPreciousRatio();

        if ($isPrecious) {
            $precious = $data->getPreciousCount();
            $this->getLogger()->info("[AntiXray] $name mined precious ore. Total: $precious, Ratio: " . round($ratio * 100, 1) . "%");
        }

        if ($ratio >= self::BAN_RATIO && $data->getViolations() >= 3) {
            $this->broadcastAlert("§4[AntiXray] §cBanning §e$name §cfor X-Ray (Ratio: " . round($ratio * 100) . "%)");
            $player->kick("§c[AntiXray] §7You have been banned for X-Ray hacking.");
            $this->getServer()->getNameBans()->addBan($name, "AntiXray: Suspicious mining pattern", null, "AutoBan");
        } elseif ($ratio >= self::SUSPICIOUS_RATIO) {
            $data->addViolation();
            $violations = $data->getViolations();

            if ($violations === 1) {
                $this->broadcastAlert(
                    "§6[AntiXray] §ePlayer §f$name §emining suspicious diamonds (Ratio: " .
                    round($ratio * 100) . "%, VL: $violations)"
                );
                $player->sendMessage("§6[AntiXray] §eYour mining pattern looks suspicious. Mining monitored.");
            } elseif ($violations >= 2) {
                $this->broadcastAlert(
                    "§c[AntiXray] §7Player §e$name §7placed in monitoring mode (VL: $violations)"
                );
                // Could log to file for admin review
                $this->logSuspicious($name, $ratio, $data->getPreciousCount(), $total);
            }
        }
    }

    private function broadcastAlert(string $msg): void {
        $this->getLogger()->warning(strip_tags($msg));
        foreach ($this->getServer()->getOnlinePlayers() as $p) {
            if ($p->isOp()) {
                $p->sendMessage($msg);
            }
        }
    }

    private function logSuspicious(string $name, float $ratio, int $precious, int $total): void {
        $logDir = $this->getDataFolder();
        @mkdir($logDir, 0755, true);
        $log = date("[Y-m-d H:i:s]") . " SUSPICIOUS: $name | Ratio: " . round($ratio * 100, 1) . "% | Precious: $precious | Total: $total\n";
        file_put_contents($logDir . "xray_suspects.log", $log, FILE_APPEND);
    }
}

class MiningData {
    private int $totalBlocks = 0;
    private int $oreBlocks = 0;
    private int $preciousBlocks = 0;
    private int $violations = 0;
    private float $sessionStart;

    public function __construct() {
        $this->sessionStart = microtime(true);
    }

    public function addBlock(bool $precious, bool $ore): void {
        $this->totalBlocks++;
        if ($ore) $this->oreBlocks++;
        if ($precious) $this->preciousBlocks++;
    }

    public function getTotalBlocks(): int { return $this->totalBlocks; }
    public function getPreciousCount(): int { return $this->preciousBlocks; }

    public function getPreciousRatio(): float {
        if ($this->totalBlocks === 0) return 0.0;
        return $this->preciousBlocks / $this->totalBlocks;
    }

    public function addViolation(): void { $this->violations++; }
    public function getViolations(): int { return $this->violations; }

    public function getSessionTime(): float {
        return microtime(true) - $this->sessionStart;
    }

    public function resetSession(): void {
        $this->totalBlocks = 0;
        $this->oreBlocks = 0;
        $this->preciousBlocks = 0;
        $this->sessionStart = microtime(true);
    }
}
