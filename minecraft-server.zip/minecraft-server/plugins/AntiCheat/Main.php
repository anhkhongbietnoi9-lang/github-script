<?php
declare(strict_types=1);

namespace AntiCheat;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\player\Player;
use pocketmine\math\Vector3;
use pocketmine\scheduler\ClosureTask;

class Main extends PluginBase implements Listener {

    /** @var array<string, PlayerData> */
    private array $playerData = [];

    // Thresholds
    private const FLY_MAX_Y_GAIN = 0.6;
    private const SPEED_MAX_HORIZONTAL = 0.5;
    private const REACH_MAX_DISTANCE = 5.5;
    private const AUTOCLK_MAX_CPS = 20;
    private const KILLAURA_SPAN_ANGLE = 120;
    private const MAX_VIOLATIONS = 5;
    private const BAN_VIOLATIONS = 10;

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("§aAntiCheat enabled.");

        // Periodic violation decay
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            foreach ($this->playerData as $data) {
                $data->decayViolations();
            }
        }), 200); // every 10 seconds
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $this->playerData[$player->getName()] = new PlayerData($player);
    }

    public function onQuit(PlayerQuitEvent $event): void {
        unset($this->playerData[$event->getPlayer()->getName()]);
    }

    public function onMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();

        if ($player->hasPermission("anticheat.bypass")) return;

        $data = $this->playerData[$player->getName()] ?? null;
        if ($data === null) return;

        $from = $event->getFrom();
        $to = $event->getTo();

        $dx = abs($to->getX() - $from->getX());
        $dz = abs($to->getZ() - $from->getZ());
        $dy = $to->getY() - $from->getY();

        $horizontal = sqrt($dx * $dx + $dz * $dz);

        // --- Fly Hack Detection ---
        if (!$player->isOnGround() && !$player->isFlying() && !$player->getAllowFlight()) {
            if ($dy > self::FLY_MAX_Y_GAIN) {
                $data->addViolation("FlyHack");
                $this->handleViolation($player, $data, "FlyHack", "Fly Hack");
            }
        }

        // --- Speed Hack Detection ---
        if ($horizontal > self::SPEED_MAX_HORIZONTAL && !$player->isSprinting()) {
            if ($horizontal > self::SPEED_MAX_HORIZONTAL * 2.5) {
                $data->addViolation("SpeedHack");
                $this->handleViolation($player, $data, "SpeedHack", "Speed Hack");
            }
        }

        // --- NoClip Detection ---
        $blockAt = $player->getWorld()->getBlock($to);
        if (!$blockAt->isTransparent() && $blockAt->isSolid()) {
            $data->addViolation("NoClip");
            $this->handleViolation($player, $data, "NoClip", "NoClip Hack");
        }

        $data->setLastPosition($to);
    }

    public function onAttack(EntityDamageByEntityEvent $event): void {
        $damager = $event->getDamager();
        if (!($damager instanceof Player)) return;
        if ($damager->hasPermission("anticheat.bypass")) return;

        $data = $this->playerData[$damager->getName()] ?? null;
        if ($data === null) return;

        $target = $event->getEntity();

        // --- Reach Hack ---
        $dist = $damager->getPosition()->distance($target->getPosition());
        if ($dist > self::REACH_MAX_DISTANCE) {
            $event->cancel();
            $data->addViolation("ReachHack");
            $this->handleViolation($damager, $data, "ReachHack", "Reach Hack");
        }

        // --- AutoClick Detection ---
        $data->registerHit();
        $cps = $data->getCPS();
        if ($cps > self::AUTOCLK_MAX_CPS) {
            $data->addViolation("AutoClick");
            $this->handleViolation($damager, $data, "AutoClick", "abnormal attack speed (CPS: $cps)");
        }

        // --- KillAura Detection ---
        if ($target instanceof Player) {
            $angle = $this->getAngle($damager, $target);
            if ($angle > self::KILLAURA_SPAN_ANGLE) {
                $event->cancel();
                $data->addViolation("KillAura");
                $this->handleViolation($damager, $data, "KillAura", "KillAura");
            }
        }
    }

    private function getAngle(Player $from, Player $to): float {
        $dir = $from->getDirectionVector();
        $diff = $to->getPosition()->subtractVector($from->getPosition())->normalize();
        $dot = $dir->dot($diff);
        $dot = max(-1.0, min(1.0, $dot));
        return rad2deg(acos($dot));
    }

    private function handleViolation(Player $player, PlayerData $data, string $type, string $label): void {
        $name = $player->getName();
        $violations = $data->getViolations($type);

        $this->broadcastAlert("§c[AntiCheat] §7Player §e$name §7suspected §c$label §7(VL: $violations)");

        if ($violations >= self::BAN_VIOLATIONS) {
            $this->broadcastAlert("§4[AntiCheat] §cBanning §e$name §cfor §4$label §c(VL: $violations)");
            $player->kick("§c[AntiCheat] §7You have been banned for §c$label.\nIf this is wrong, contact an admin.");
            $this->getServer()->getNameBans()->addBan($name, "AntiCheat: $label", null, "AutoBan");
        } elseif ($violations >= self::MAX_VIOLATIONS) {
            $this->broadcastAlert("§6[AntiCheat] §eKicking §f$name §efor §6$label §e(VL: $violations)");
            $player->kick("§c[AntiCheat] §7You were kicked for §c$label.");
        }
    }

    private function broadcastAlert(string $msg): void {
        $this->getLogger()->warning(strip_tags($msg));
        foreach ($this->getServer()->getOnlinePlayers() as $p) {
            if ($p->hasPermission("anticheat.notify") || $p->isOp()) {
                $p->sendMessage($msg);
            }
        }
    }
}

class PlayerData {
    private Vector3 $lastPos;
    /** @var array<string, int> */
    private array $violations = [];
    /** @var float[] */
    private array $hitTimes = [];

    public function __construct(Player $player) {
        $this->lastPos = $player->getPosition()->asVector3();
    }

    public function setLastPosition(Vector3 $pos): void {
        $this->lastPos = $pos;
    }

    public function getLastPosition(): Vector3 {
        return $this->lastPos;
    }

    public function addViolation(string $type): void {
        $this->violations[$type] = ($this->violations[$type] ?? 0) + 1;
    }

    public function getViolations(string $type): int {
        return $this->violations[$type] ?? 0;
    }

    public function decayViolations(): void {
        foreach ($this->violations as $type => $count) {
            if ($count > 0) {
                $this->violations[$type] = max(0, $count - 1);
            }
        }
    }

    public function registerHit(): void {
        $now = microtime(true);
        $this->hitTimes[] = $now;
        // Keep only last 2 seconds
        $this->hitTimes = array_filter($this->hitTimes, fn($t) => ($now - $t) <= 1.0);
        $this->hitTimes = array_values($this->hitTimes);
    }

    public function getCPS(): int {
        $now = microtime(true);
        $recent = array_filter($this->hitTimes, fn($t) => ($now - $t) <= 1.0);
        return count($recent);
    }
}
