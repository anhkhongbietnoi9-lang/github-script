<?php
declare(strict_types=1);

namespace AntiLag;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntitySpawnEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\entity\object\ItemEntity;
use pocketmine\entity\Living;
use pocketmine\player\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\scheduler\ClosureTask;

class Main extends PluginBase implements Listener {

    private const MAX_ITEMS = 100;
    private const MAX_ENTITIES_WORLD = 150;
    private const ITEM_CLEANUP_TICKS = 2400;  // 2 min
    private const ENTITY_CLEANUP_TICKS = 6000; // 5 min
    private const CHAT_COOLDOWN = 1.0; // seconds
    private const INTERACT_COOLDOWN = 0.2;

    /** @var float[] */
    private array $lastChat = [];
    /** @var float[] */
    private array $lastInteract = [];

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("§aAntiLag enabled.");

        // Item cleanup
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->cleanupItems();
        }), self::ITEM_CLEANUP_TICKS);

        // Full entity cleanup
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->cleanupEntities();
        }), self::ENTITY_CLEANUP_TICKS);

        // 10-second warning before entity cleanup
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            static $warned = false;
            // Warn 10 ticks before cleanup
        }), self::ENTITY_CLEANUP_TICKS - 200);
    }

    private function cleanupItems(): void {
        $removed = 0;
        foreach ($this->getServer()->getWorldManager()->getWorlds() as $world) {
            $items = [];
            foreach ($world->getEntities() as $entity) {
                if ($entity instanceof ItemEntity) {
                    $items[] = $entity;
                }
            }
            if (count($items) > self::MAX_ITEMS) {
                $toRemove = array_slice($items, 0, count($items) - self::MAX_ITEMS);
                foreach ($toRemove as $item) {
                    $item->flagForDespawn();
                    $removed++;
                }
            }
        }
        if ($removed > 0) {
            $this->broadcast("§7[AntiLag] §fRemoved $removed dropped items to reduce lag.");
        }
    }

    private function cleanupEntities(): void {
        $total = 0;
        foreach ($this->getServer()->getWorldManager()->getWorlds() as $world) {
            $entities = $world->getEntities();
            $count = count($entities);

            if ($count <= self::MAX_ENTITIES_WORLD) continue;

            // Warn first
            $this->broadcast("§e[AntiLag] §fClearing entities in §c10 seconds§f...");

            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($world, &$total): void {
                $removed = 0;
                foreach ($world->getEntities() as $entity) {
                    if ($entity instanceof Player) continue;
                    // Keep named entities
                    if (!($entity instanceof Living) && !($entity instanceof ItemEntity)) continue;
                    $entity->flagForDespawn();
                    $removed++;
                    $total++;
                }
                if ($removed > 0) {
                    $this->broadcast("§a[AntiLag] §fRemoved §e$removed §fentities. Server should be smoother.");
                }
            }), 200);
        }
    }

    public function onEntitySpawn(EntitySpawnEvent $event): void {
        $entity = $event->getEntity();
        $world = $entity->getWorld();

        // Check item count
        if ($entity instanceof ItemEntity) {
            $items = 0;
            foreach ($world->getEntities() as $e) {
                if ($e instanceof ItemEntity) $items++;
            }
            if ($items > self::MAX_ITEMS * 1.5) {
                $entity->flagForDespawn();
            }
        }

        // Check total entity count
        $entityCount = count($world->getEntities());
        if ($entityCount > self::MAX_ENTITIES_WORLD * 1.5) {
            if (!($entity instanceof Player)) {
                $entity->flagForDespawn();
            }
        }
    }

    public function onChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();
        $now = microtime(true);

        if (isset($this->lastChat[$name]) && ($now - $this->lastChat[$name]) < self::CHAT_COOLDOWN) {
            $event->cancel();
            $player->sendMessage("§c[AntiLag] §7Chat spam detected! Slow down.");
            return;
        }
        $this->lastChat[$name] = $now;
    }

    public function onInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();
        $now = microtime(true);

        if (isset($this->lastInteract[$name]) && ($now - $this->lastInteract[$name]) < self::INTERACT_COOLDOWN) {
            $event->cancel();
            return;
        }
        $this->lastInteract[$name] = $now;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "lagclear") {
            $this->cleanupItems();
            $this->cleanupEntities();
            $sender->sendMessage("§a[AntiLag] §fLag clear triggered.");
            return true;
        }
        return false;
    }

    private function broadcast(string $msg): void {
        $this->getLogger()->info(strip_tags($msg));
        $this->getServer()->broadcastMessage($msg);
    }
}
