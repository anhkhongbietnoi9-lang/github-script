<?php
/**
 * ============================================================
 * Baconrobloxian's Minecraft Server - Web API Server
 * Standalone PHP HTTP server for Web Control Panel
 * Port: 8080
 * ============================================================
 */

declare(strict_types=1);

// --- Config ---
define('API_KEY_FILE', __DIR__ . '/../../data/api_key.txt');
define('DATA_DIR',     __DIR__ . '/../../data/');
define('CHAT_LOG',     __DIR__ . '/../../plugins/ChatLogger/data/chat_history.json');
define('ADMIN_FILE',   __DIR__ . '/../../plugins/OwnerProtect/data/admins.yml');
define('SERVER_LOG',   __DIR__ . '/../../logs/server.log');
define('SERVER_PID',   '/tmp/mc_server.pid');
define('PORT',         8080);
define('OWNER_NAME',   'Baconrobloxian');

// --- Init ---
@mkdir(DATA_DIR, 0755, true);

// Generate/load API key
function getApiKey(): string {
    if (!file_exists(API_KEY_FILE)) {
        $key = bin2hex(random_bytes(16));
        file_put_contents(API_KEY_FILE, $key);
        echo "[API] Generated API Key: $key\n";
        return $key;
    }
    return trim(file_get_contents(API_KEY_FILE));
}

$API_KEY = getApiKey();
echo "[API] Web Control Panel starting on port " . PORT . "\n";
echo "[API] API Key: $API_KEY\n";
echo "[API] Use Authorization: $API_KEY in headers\n";

// --- Simple HTTP Server ---
$server = stream_socket_server("tcp://0.0.0.0:" . PORT, $errno, $errstr);
if (!$server) {
    echo "[API] Failed to start: $errstr ($errno)\n";
    exit(1);
}
echo "[API] Running. Visit http://localhost:" . PORT . "/\n";

while (true) {
    $client = @stream_socket_accept($server, 5);
    if (!$client) continue;

    $request = '';
    while (!feof($client)) {
        $line = fgets($client, 1024);
        if ($line === false || $line === "\r\n") break;
        $request .= $line;
    }

    // Read body
    $body = '';
    if (preg_match('/Content-Length: (\d+)/i', $request, $m)) {
        $body = fread($client, (int)$m[1]);
    }

    handleRequest($client, $request, $body, $API_KEY);
    fclose($client);
}

function handleRequest($client, string $request, string $body, string $apiKey): void {
    // Parse request line
    $lines = explode("\n", $request);
    $reqLine = trim($lines[0]);
    [$method, $path] = explode(' ', $reqLine . '  ');
    $path = parse_url(trim($path), PHP_URL_PATH) ?? '/';

    // Parse headers
    $headers = [];
    foreach ($lines as $line) {
        if (strpos($line, ':') !== false) {
            [$k, $v] = explode(':', $line, 2);
            $headers[strtolower(trim($k))] = trim($v);
        }
    }

    // CORS headers
    $cors = "Access-Control-Allow-Origin: *\r\n" .
            "Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS\r\n" .
            "Access-Control-Allow-Headers: Authorization, Content-Type\r\n";

    if ($method === 'OPTIONS') {
        respond($client, 204, '', $cors);
        return;
    }

    // Auth check (except /ping and /api/key)
    if ($path !== '/ping' && $path !== '/api/key') {
        $authHeader = $headers['authorization'] ?? '';
        if ($authHeader !== $apiKey) {
            respond($client, 403, json_encode(['error' => 'Invalid API key', 'message' => 'Please provide valid Authorization header']), $cors);
            return;
        }
    }

    $data = json_decode($body, true) ?? [];

    // --- Route ---
    $response = route($method, $path, $data, $apiKey);
    respond($client, $response['code'] ?? 200, json_encode($response['data'] ?? []), $cors);
}

function route(string $method, string $path, array $data, string $apiKey): array {
    // GET /ping
    if ($method === 'GET' && $path === '/ping') {
        return ok(['status' => 'online', 'server' => 'Baconrobloxian\'s Server', 'owner' => OWNER_NAME]);
    }

    // GET /api/key (returns masked key)
    if ($method === 'GET' && $path === '/api/key') {
        $k = getApiKey();
        return ok(['key' => substr($k, 0, 6) . '...' . substr($k, -6), 'hint' => 'Full key in data/api_key.txt']);
    }

    // --- Server Status ---
    if ($method === 'GET' && $path === '/api/status') {
        return ok(getServerStatus());
    }

    // --- Players ---
    if ($method === 'GET' && $path === '/api/players') {
        return ok(['players' => getOnlinePlayers(), 'count' => count(getOnlinePlayers())]);
    }

    if ($method === 'POST' && $path === '/api/players/kick') {
        if (empty($data['player'])) return err('player required');
        if (isOwner($data['player'])) return err('Cannot kick server owner', 403);
        $reason = $data['reason'] ?? 'Kicked by admin via Web Panel';
        execServerCommand("kick {$data['player']} $reason");
        logAction('kick', $data['player'], $reason);
        return ok(['message' => "Kicked {$data['player']}"]);
    }

    if ($method === 'POST' && $path === '/api/players/ban') {
        if (empty($data['player'])) return err('player required');
        if (isOwner($data['player'])) return err('Cannot ban server owner', 403);
        $reason = $data['reason'] ?? 'Banned by admin via Web Panel';
        execServerCommand("ban {$data['player']} $reason");
        logAction('ban', $data['player'], $reason);
        return ok(['message' => "Banned {$data['player']}"]);
    }

    if ($method === 'POST' && $path === '/api/players/kill') {
        if (empty($data['player'])) return err('player required');
        if (isOwner($data['player'])) return err('Cannot kill server owner', 403);
        execServerCommand("kill {$data['player']}");
        logAction('kill', $data['player'], '');
        return ok(['message' => "Killed {$data['player']}"]);
    }

    if ($method === 'POST' && $path === '/api/players/gamemode') {
        if (empty($data['player']) || !isset($data['mode'])) return err('player and mode required');
        if (isOwner($data['player'])) return err('Cannot change owner gamemode', 403);
        $mode = in_array($data['mode'], ['survival','creative','adventure','spectator']) ? $data['mode'] : 'survival';
        execServerCommand("gamemode $mode {$data['player']}");
        logAction('gamemode', $data['player'], $mode);
        return ok(['message' => "Set {$data['player']} to $mode"]);
    }

    // --- Inventory ---
    if ($method === 'GET' && preg_match('#^/api/inventory/(.+)$#', $path, $m)) {
        return ok(['player' => $m[1], 'note' => 'Inventory viewing requires PMMP plugin integration', 'inventory' => []]);
    }

    if ($method === 'POST' && $path === '/api/inventory/clear') {
        if (empty($data['player'])) return err('player required');
        if (isOwner($data['player'])) return err('Cannot clear owner inventory', 403);
        execServerCommand("clear {$data['player']}");
        logAction('clear_inventory', $data['player'], '');
        return ok(['message' => "Cleared inventory of {$data['player']}"]);
    }

    if ($method === 'POST' && $path === '/api/inventory/give') {
        if (empty($data['player']) || empty($data['item'])) return err('player and item required');
        $amount = (int)($data['amount'] ?? 1);
        execServerCommand("give {$data['player']} {$data['item']} $amount");
        logAction('give', $data['player'], "{$data['item']} x$amount");
        return ok(['message' => "Gave {$data['item']} x$amount to {$data['player']}"]);
    }

    // --- Admins ---
    if ($method === 'GET' && $path === '/api/admins') {
        return ok(['admins' => getAdminList()]);
    }

    if ($method === 'POST' && $path === '/api/admins/add') {
        if (empty($data['player'])) return err('player required');
        if (isOwner($data['player'])) return err('Owner cannot be added as admin', 403);
        addAdmin($data['player']);
        execServerCommand("addadmin {$data['player']}");
        return ok(['message' => "Added admin: {$data['player']}"]);
    }

    if ($method === 'DELETE' && $path === '/api/admins/remove') {
        if (empty($data['player'])) return err('player required');
        if (isOwner($data['player'])) return err('Cannot remove owner', 403);
        removeAdmin($data['player']);
        execServerCommand("removeadmin {$data['player']}");
        return ok(['message' => "Removed admin: {$data['player']}"]);
    }

    // --- Chat ---
    if ($method === 'GET' && $path === '/api/chat') {
        $limit = (int)($_GET['limit'] ?? 100);
        return ok(['messages' => getChatHistory($limit)]);
    }

    // --- Server Control ---
    if ($method === 'POST' && $path === '/api/server/restart') {
        execServerCommand("stop");
        logAction('restart', 'admin', 'Web Panel restart');
        return ok(['message' => 'Server restart initiated']);
    }

    if ($method === 'POST' && $path === '/api/server/stop') {
        execServerCommand("stop");
        logAction('stop', 'admin', 'Web Panel stop');
        return ok(['message' => 'Server stop initiated']);
    }

    if ($method === 'GET' && $path === '/api/server/log') {
        $lines = 100;
        $log = getServerLog($lines);
        return ok(['log' => $log]);
    }

    if ($method === 'POST' && $path === '/api/server/command') {
        if (empty($data['command'])) return err('command required');
        $cmd = $data['command'];
        // Block dangerous commands
        $blocked = ['rm', 'del', 'format', 'shutdown'];
        foreach ($blocked as $b) {
            if (str_starts_with(strtolower($cmd), $b)) return err('Command not allowed');
        }
        execServerCommand($cmd);
        return ok(['message' => "Executed: $cmd"]);
    }

    // --- Plugins ---
    if ($method === 'GET' && $path === '/api/plugins') {
        return ok(['plugins' => listPlugins()]);
    }

    if ($method === 'DELETE' && $path === '/api/plugins/remove') {
        if (empty($data['plugin'])) return err('plugin required');
        $result = removePlugin($data['plugin']);
        return ok(['message' => $result]);
    }

    return ['code' => 404, 'data' => ['error' => 'Not found', 'path' => $path]];
}

// --- Helpers ---
function ok(array $data): array { return ['code' => 200, 'data' => $data]; }
function err(string $msg, int $code = 400): array { return ['code' => $code, 'data' => ['error' => $msg]]; }

function isOwner(string $name): bool {
    return strtolower($name) === strtolower(OWNER_NAME);
}

function getServerStatus(): array {
    $online = isServerRunning();
    $players = getOnlinePlayers();
    return [
        'online' => $online,
        'name' => "Baconrobloxian's Server",
        'owner' => OWNER_NAME,
        'player_count' => count($players),
        'max_players' => 20,
        'port' => 19132,
        'gamemode' => 'survival',
        'difficulty' => 'normal',
        'pvp' => true,
        'uptime' => getUptime(),
        'version' => 'PocketMine-MP',
    ];
}

function isServerRunning(): bool {
    if (file_exists(SERVER_PID)) {
        $pid = trim(file_get_contents(SERVER_PID));
        return posix_kill((int)$pid, 0);
    }
    return false;
}

function getUptime(): string {
    $uptimeFile = DATA_DIR . 'start_time.txt';
    if (!file_exists($uptimeFile)) return 'Unknown';
    $start = (int)file_get_contents($uptimeFile);
    $diff = time() - $start;
    $h = floor($diff / 3600);
    $m = floor(($diff % 3600) / 60);
    return "{$h}h {$m}m";
}

function getOnlinePlayers(): array {
    $file = DATA_DIR . 'online_players.json';
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function getChatHistory(int $limit = 100): array {
    if (!file_exists(CHAT_LOG)) return [];
    $raw = file_get_contents(CHAT_LOG);
    $history = json_decode($raw, true) ?? [];
    return array_slice($history, -$limit);
}

function getAdminList(): array {
    $file = DATA_DIR . 'admins.json';
    if (!file_exists($file)) return [];
    return json_decode(file_get_contents($file), true) ?? [];
}

function addAdmin(string $name): void {
    $admins = getAdminList();
    if (!in_array(strtolower($name), array_map('strtolower', $admins))) {
        $admins[] = $name;
        file_put_contents(DATA_DIR . 'admins.json', json_encode($admins));
    }
}

function removeAdmin(string $name): void {
    $admins = getAdminList();
    $admins = array_filter($admins, fn($a) => strtolower($a) !== strtolower($name));
    file_put_contents(DATA_DIR . 'admins.json', json_encode(array_values($admins)));
}

function execServerCommand(string $command): void {
    // Write to command pipe file (PMMP reads this)
    $pipe = DATA_DIR . 'server_commands.txt';
    file_put_contents($pipe, $command . "\n", FILE_APPEND);
    echo "[API] Command queued: $command\n";
}

function getServerLog(int $lines = 100): array {
    if (!file_exists(SERVER_LOG)) return [];
    $all = file(SERVER_LOG, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
    return array_slice($all, -$lines);
}

function listPlugins(): array {
    $pluginDir = __DIR__ . '/../../plugins/';
    $plugins = [];
    if (is_dir($pluginDir)) {
        foreach (scandir($pluginDir) as $item) {
            if ($item[0] === '.') continue;
            $yamlFile = $pluginDir . $item . '/plugin.yml';
            if (file_exists($yamlFile)) {
                $content = file_get_contents($yamlFile);
                preg_match('/^name:\s*(.+)$/m', $content, $name);
                preg_match('/^version:\s*"?(.+?)"?$/m', $content, $ver);
                preg_match('/^description:\s*(.+)$/m', $content, $desc);
                $plugins[] = [
                    'folder' => $item,
                    'name' => trim($name[1] ?? $item),
                    'version' => trim($ver[1] ?? '?'),
                    'description' => trim($desc[1] ?? ''),
                ];
            }
        }
    }
    return $plugins;
}

function removePlugin(string $name): string {
    $pluginDir = __DIR__ . '/../../plugins/' . $name;
    if (!is_dir($pluginDir)) return "Plugin not found: $name";
    // Safety: don't remove core plugins
    $protected = ['OwnerProtect', 'AntiCheat', 'AntiXray', 'AntiLag', 'ChatLogger', 'ApiServer'];
    if (in_array($name, $protected)) return "Cannot remove protected plugin: $name";
    // Rename to disabled
    rename($pluginDir, $pluginDir . '_disabled');
    return "Plugin disabled: $name (restart required)";
}

function logAction(string $action, string $target, string $detail): void {
    $logFile = DATA_DIR . 'admin_actions.json';
    $log = [];
    if (file_exists($logFile)) {
        $log = json_decode(file_get_contents($logFile), true) ?? [];
    }
    $log[] = [
        'action' => $action,
        'target' => $target,
        'detail' => $detail,
        'time' => date('Y-m-d H:i:s'),
    ];
    if (count($log) > 200) $log = array_slice($log, -200);
    file_put_contents($logFile, json_encode($log, JSON_PRETTY_PRINT));
}

function respond($client, int $code, string $body, string $extraHeaders = ''): void {
    $statusText = match($code) {
        200 => 'OK', 204 => 'No Content', 400 => 'Bad Request',
        403 => 'Forbidden', 404 => 'Not Found', default => 'OK'
    };
    $len = strlen($body);
    $response = "HTTP/1.1 $code $statusText\r\n" .
                "Content-Type: application/json\r\n" .
                "Content-Length: $len\r\n" .
                $extraHeaders .
                "Connection: close\r\n\r\n" .
                $body;
    fwrite($client, $response);
}
