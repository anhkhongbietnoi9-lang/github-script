<?php
declare(strict_types=1);

namespace OwnerProtect;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {

    private const OWNER_NAME = "Baconrobloxian";

    // Commands admins CANNOT use on the owner
    private const BLOCKED_COMMANDS = [
        "ban", "ban-ip", "kick", "kill", "op", "deop",
        "gamemode", "gm", "clear", "give", "tp", "teleport"
    ];

    private Config $adminConfig;
    /** @var string[] */
    private array $admins = [];

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $this->adminConfig = new Config($this->getDataFolder() . "admins.yml", Config::YAML);
        $this->admins = $this->adminConfig->get("admins", []);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("§aOwnerProtect enabled. Owner: " . self::OWNER_NAME);
    }

    public function onDisable(): void {
        $this->saveAdmins();
    }

    private function saveAdmins(): void {
        $this->adminConfig->set("admins", $this->admins);
        $this->adminConfig->save();
    }

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();

        // Special join message for owner
        if (strtolower($name) === strtolower(self::OWNER_NAME)) {
            $this->getServer()->broadcastMessage(
                "§6§l[Server] §r§eOwner §c§l" . self::OWNER_NAME . " §r§ehas joined the game!"
            );

            // Give owner OP status
            if (!$player->hasPermission("pocketmine.command.op")) {
                $this->getServer()->addOp($name);
            }
            $player->sendMessage("§6§l[Server] §r§aWelcome back, Owner! You have full server control.");
        }

        // Notify admins list
        if (in_array(strtolower($name), array_map('strtolower', $this->admins))) {
            $player->sendMessage("§b[Server] §aYou are an Admin on this server.");
        }
    }

    public function onCommand(CommandEvent $event): void {
        $sender = $event->getSender();
        $commandLine = $event->getCommand();

        // Parse command
        $parts = explode(" ", trim($commandLine));
        $cmd = strtolower(ltrim($parts[0], "/"));
        $targetArg = $parts[1] ?? null;

        if ($targetArg === null) return;

        // Check if command targets the owner
        if (strtolower($targetArg) !== strtolower(self::OWNER_NAME)) return;

        // Owner can do anything
        if ($sender instanceof Player && strtolower($sender->getName()) === strtolower(self::OWNER_NAME)) return;

        // Block restricted commands against owner
        if (in_array($cmd, self::BLOCKED_COMMANDS)) {
            $event->cancel();
            if ($sender instanceof Player) {
                $sender->sendMessage("§c[Permission] §7You cannot use this command on the server owner.");
            } else {
                $this->getLogger()->warning("[Permission] Blocked command '$cmd' against owner.");
            }
        }
    }

    public function onCommandRun(CommandSender $sender, Command $command, string $label, array $args): bool {
        switch ($command->getName()) {
            case "addadmin":
                return $this->cmdAddAdmin($sender, $args);
            case "removeadmin":
                return $this->cmdRemoveAdmin($sender, $args);
            case "listadmins":
                return $this->cmdListAdmins($sender);
            case "ownerinfo":
                return $this->cmdOwnerInfo($sender);
        }
        return false;
    }

    private function cmdAddAdmin(CommandSender $sender, array $args): bool {
        if (!isset($args[0])) {
            $sender->sendMessage("§cUsage: /addadmin <player>");
            return true;
        }
        $name = $args[0];
        if (strtolower($name) === strtolower(self::OWNER_NAME)) {
            $sender->sendMessage("§c[OwnerProtect] Cannot add owner as admin.");
            return true;
        }
        if (!in_array(strtolower($name), array_map('strtolower', $this->admins))) {
            $this->admins[] = $name;
            $this->saveAdmins();

            // Grant OP
            $this->getServer()->addOp($name);

            $sender->sendMessage("§a[Admin] §7Added admin: §e$name");
            $this->getLogger()->info("[Admin] $name added as admin by " . $sender->getName());

            // Notify the player if online
            $target = $this->getServer()->getPlayerByPrefix($name);
            if ($target !== null) {
                $target->sendMessage("§b[Server] §aYou have been promoted to Admin by " . $sender->getName());
            }
        } else {
            $sender->sendMessage("§e[Admin] §7$name is already an admin.");
        }
        return true;
    }

    private function cmdRemoveAdmin(CommandSender $sender, array $args): bool {
        if (!isset($args[0])) {
            $sender->sendMessage("§cUsage: /removeadmin <player>");
            return true;
        }
        $name = $args[0];
        $key = array_search(strtolower($name), array_map('strtolower', $this->admins));
        if ($key !== false) {
            unset($this->admins[$key]);
            $this->admins = array_values($this->admins);
            $this->saveAdmins();

            // Remove OP
            $this->getServer()->removeOp($name);

            $sender->sendMessage("§a[Admin] §7Removed admin: §e$name");

            $target = $this->getServer()->getPlayerByPrefix($name);
            if ($target !== null) {
                $target->sendMessage("§c[Server] §7Your admin privileges have been removed.");
            }
        } else {
            $sender->sendMessage("§e[Admin] §7$name is not an admin.");
        }
        return true;
    }

    private function cmdListAdmins(CommandSender $sender): bool {
        if (empty($this->admins)) {
            $sender->sendMessage("§b[Admin] §7No admins found.");
            return true;
        }
        $sender->sendMessage("§b[Admin] §eAdmin List (" . count($this->admins) . "):");
        foreach ($this->admins as $admin) {
            $online = $this->getServer()->getPlayerByPrefix($admin) !== null;
            $status = $online ? "§a[Online]" : "§7[Offline]";
            $sender->sendMessage("  §f- §e$admin $status");
        }
        return true;
    }

    private function cmdOwnerInfo(CommandSender $sender): bool {
        $sender->sendMessage("§6§l=== Server Owner ===");
        $sender->sendMessage("§eOwner: §f" . self::OWNER_NAME);
        $ownerOnline = $this->getServer()->getPlayerByPrefix(self::OWNER_NAME) !== null;
        $status = $ownerOnline ? "§a[Online]" : "§7[Offline]";
        $sender->sendMessage("§eStatus: $status");
        $sender->sendMessage("§eProtection: §aActive");
        return true;
    }

    /** @return string[] */
    public function getAdmins(): array {
        return $this->admins;
    }

    public function isOwner(string $name): bool {
        return strtolower($name) === strtolower(self::OWNER_NAME);
    }
}
