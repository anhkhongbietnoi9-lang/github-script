<?php
declare(strict_types=1);

namespace ChatLogger;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;

class Main extends PluginBase implements Listener {

    private string $logFile;

    public function onEnable(): void {
        @mkdir($this->getDataFolder(), 0755, true);
        $this->logFile = $this->getDataFolder() . "chat_history.json";

        // Initialize file
        if (!file_exists($this->logFile)) {
            file_put_contents($this->logFile, json_encode([], JSON_PRETTY_PRINT));
        }

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("§aChatLogger enabled.");
    }

    public function onChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        $message = $event->getMessage();
        $timestamp = date("Y-m-d H:i:s");
        $timeShort = date("H:i");

        $entry = [
            "player" => $player->getName(),
            "message" => $message,
            "timestamp" => $timestamp,
            "time_short" => $timeShort,
            "xuid" => $player->getXuid(),
        ];

        // Load existing
        $history = [];
        $raw = file_get_contents($this->logFile);
        if ($raw !== false) {
            $history = json_decode($raw, true) ?? [];
        }

        $history[] = $entry;

        // Keep last 500 messages
        if (count($history) > 500) {
            $history = array_slice($history, -500);
        }

        file_put_contents($this->logFile, json_encode($history, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    /** @return array<mixed> */
    public function getChatHistory(int $limit = 100): array {
        $raw = file_get_contents($this->logFile);
        if ($raw === false) return [];
        $history = json_decode($raw, true) ?? [];
        return array_slice($history, -$limit);
    }

    public function getLogFilePath(): string {
        return $this->logFile;
    }
}
