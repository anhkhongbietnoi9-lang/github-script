#!/bin/bash
# ============================================
# PocketMine-MP Server Start Script for Termux
# Server Owner: Baconrobloxian
# ============================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PHP_BIN="./bin/php7/bin/php"
PHAR_FILE="./PocketMine-MP.phar"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════╗"
echo "║   Baconrobloxian's Minecraft Server      ║"
echo "║   PocketMine-MP | Termux Optimized       ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"

# --- Check Dependencies ---
check_deps() {
  echo -e "${YELLOW}[Setup] Checking dependencies...${NC}"

  if ! command -v php &>/dev/null && [ ! -f "$PHP_BIN" ]; then
    echo -e "${YELLOW}[Setup] PHP not found. Installing via pkg...${NC}"
    pkg update -y && pkg install -y php
    if [ $? -ne 0 ]; then
      echo -e "${RED}[Error] Failed to install PHP. Please run: pkg install php${NC}"
      exit 1
    fi
  fi

  if command -v php &>/dev/null && [ ! -f "$PHP_BIN" ]; then
    PHP_BIN="php"
  fi

  echo -e "${GREEN}[Setup] PHP OK: $($PHP_BIN -v | head -1)${NC}"
}

# --- Download PocketMine if not exists ---
download_pocketmine() {
  if [ ! -f "$PHAR_FILE" ]; then
    echo -e "${YELLOW}[Setup] PocketMine-MP.phar not found.${NC}"
    echo -e "${YELLOW}[Setup] Downloading latest PocketMine-MP...${NC}"

    PMMP_URL="https://github.com/pmmp/PocketMine-MP/releases/latest/download/PocketMine-MP.phar"

    if command -v curl &>/dev/null; then
      curl -L -o PocketMine-MP.phar "$PMMP_URL"
    elif command -v wget &>/dev/null; then
      wget -O PocketMine-MP.phar "$PMMP_URL"
    else
      echo -e "${RED}[Error] curl/wget not found. Run: pkg install curl${NC}"
      exit 1
    fi

    if [ ! -f "$PHAR_FILE" ]; then
      echo -e "${RED}[Error] Download failed. Check internet connection.${NC}"
      exit 1
    fi
    echo -e "${GREEN}[Setup] PocketMine-MP downloaded!${NC}"
  fi
}

# --- Start API Server ---
start_api() {
  echo -e "${YELLOW}[API] Starting Web Control Panel API...${NC}"
  $PHP_BIN plugins/ApiServer/api_server.php &
  API_PID=$!
  echo $API_PID > /tmp/mc_api.pid
  echo -e "${GREEN}[API] Web Panel running on port 8080 (PID: $API_PID)${NC}"
}

# --- Main Start ---
main() {
  check_deps
  download_pocketmine

  # Generate API key if not exists
  if [ ! -f "data/api_key.txt" ]; then
    mkdir -p data
    API_KEY=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1)
    echo "$API_KEY" > data/api_key.txt
    echo -e "${GREEN}[API] Generated new API Key: $API_KEY${NC}"
    echo -e "${YELLOW}[API] Key saved to: data/api_key.txt${NC}"
  else
    API_KEY=$(cat data/api_key.txt)
    echo -e "${GREEN}[API] API Key loaded: $API_KEY${NC}"
  fi

  start_api

  echo -e "${GREEN}[Server] Starting PocketMine-MP...${NC}"
  echo -e "${CYAN}[Server] Owner: Baconrobloxian | Port: 19132 | MaxPlayers: 20${NC}"
  echo ""

  # Start PocketMine
  $PHP_BIN -c bin/php7/bin/php.ini $PHAR_FILE --no-wizard

  # Cleanup on exit
  if [ -f /tmp/mc_api.pid ]; then
    kill $(cat /tmp/mc_api.pid) 2>/dev/null
    rm /tmp/mc_api.pid
  fi
  echo -e "${RED}[Server] Server stopped.${NC}"
}

main "$@"
