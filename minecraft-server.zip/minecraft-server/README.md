# 🎮 Baconrobloxian's Minecraft Server
## PocketMine-MP | Termux Android Setup Guide

---

## 📱 Termux Setup (First Time)

```bash
# 1. Update packages
pkg update && pkg upgrade -y

# 2. Install required packages
pkg install -y php curl wget git

# 3. Install PHP extensions (optional but recommended)
pkg install -y php-curl

# 4. Copy server files to phone
# Use Termux:API or copy via file manager to ~/minecraft-server/

# 5. Enter server directory
cd ~/minecraft-server

# 6. Make start script executable
chmod +x start.sh

# 7. Start the server
./start.sh
```

---

## 📁 Directory Structure

```
minecraft-server/
├── start.sh                    ← Start server (run this!)
├── server.properties           ← Server settings
├── pocketmine.yml              ← PocketMine config
├── index.html                  ← Web Control Panel
├── PocketMine-MP.phar          ← (auto-downloaded)
├── data/
│   ├── api_key.txt             ← Auto-generated API key
│   ├── online_players.json     ← Player tracking
│   └── admin_actions.json      ← Admin action log
├── plugins/
│   ├── OwnerProtect/           ← Owner protection system
│   ├── AntiCheat/              ← Hack detection
│   ├── AntiXray/               ← X-Ray detection
│   ├── AntiLag/                ← Lag prevention
│   ├── ChatLogger/             ← Chat history
│   └── ApiServer/              ← Web panel API
├── logs/
│   └── server.log
└── worlds/
    └── world/
```

---

## 🔑 API Key

On first start, an API key is automatically generated:
```
API_KEY = xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

- Stored in: `data/api_key.txt`
- Used in: Web Panel → Sidebar → API Key field
- All API requests require: `Authorization: <your-api-key>`

---

## 🌐 Web Control Panel

1. Start the server (`./start.sh`)
2. Open `index.html` in any browser
3. Enter your API key in the sidebar
4. Control your server!

**API runs on:** `http://localhost:8080`

### Panel Features:
| Section | Features |
|---------|----------|
| Dashboard | Server status, player count, uptime |
| Players | View, kick, ban, kill, change gamemode |
| Inventory | View, clear, give items |
| Admins | Add/remove admins, list |
| Chat History | Full message history with timestamps |
| Plugins | List, remove plugins |
| Server Control | Restart, stop, execute commands, view log |

---

## 👑 Owner Protection (Baconrobloxian)

The owner is **fully protected**:
- ❌ Admins cannot ban/kick/kill the owner
- ❌ Admins cannot change owner's gamemode
- ❌ Admins cannot clear owner's inventory
- ✅ Owner gets special join message
- ✅ Owner always has OP automatically

If an admin tries: `[Permission] You cannot use this command on the server owner.`

---

## 🛡️ AntiCheat System

Detects and handles:
| Hack | Detection | Action |
|------|-----------|--------|
| Fly Hack | Y-axis gain > 0.6 | Warn → Kick → Ban |
| Speed Hack | Horizontal speed abnormal | Warn → Kick → Ban |
| NoClip | Moving through solid blocks | Warn → Kick → Ban |
| KillAura | Attack angle > 120° | Cancel attack → Ban |
| AutoClick | CPS > 20 | Warn → Kick → Ban |
| Reach Hack | Attack distance > 5.5 blocks | Cancel → Ban |

---

## 🔍 AntiXray System

Monitors mining patterns:
- Tracks total blocks mined vs precious ores found
- **15% ratio** = Warning + monitoring mode
- **30% ratio** + repeated violations = Auto-ban

```
[AntiXray] Player ABC mining suspicious diamonds (Ratio: 28%, VL: 2)
```

---

## ⚡ AntiLag System

| Feature | Details |
|---------|---------|
| Item cleanup | Auto-removes excess dropped items every 2 min |
| Entity cleanup | Removes excess entities every 5 min |
| Chat spam | 1 second cooldown between messages |
| Interaction spam | 0.2 second cooldown |
| Max items | 100 per world |
| Max entities | 150 per world |

Manual command: `/lagclear` (OP only)

---

## ⚙️ Server Configuration

Key settings in `server.properties`:
```properties
max-players=20
gamemode=survival
difficulty=2          # 0=peaceful, 1=easy, 2=normal, 3=hard
pvp=on
view-distance=4       # Low for mobile performance
```

---

## 🔧 Admin Commands

```
/addadmin <player>     - Add an admin
/removeadmin <player>  - Remove admin
/listadmins            - Show all admins
/ownerinfo             - Show owner info
/lagclear              - Clear entities (lag fix)
```

---

## 📡 API Endpoints

All requests need header: `Authorization: <api_key>`

```
GET  /api/status              - Server status
GET  /api/players             - Online players
POST /api/players/kick        - Kick player
POST /api/players/ban         - Ban player
POST /api/players/kill        - Kill player
POST /api/players/gamemode    - Change gamemode
GET  /api/inventory/:player   - View inventory
POST /api/inventory/give      - Give item
POST /api/inventory/clear     - Clear inventory
GET  /api/admins              - List admins
POST /api/admins/add          - Add admin
DEL  /api/admins/remove       - Remove admin
GET  /api/chat                - Chat history
GET  /api/server/log          - Server log
POST /api/server/restart      - Restart server
POST /api/server/stop         - Stop server
POST /api/server/command      - Execute command
GET  /api/plugins             - List plugins
DEL  /api/plugins/remove      - Remove plugin
```

---

## 🔋 Termux Optimization Tips

1. **Keep Termux awake**: Use Termux Wake Lock
2. **Background running**: `nohup ./start.sh &`  
3. **Screen session**: `pkg install screen && screen -S mc`
4. **Low memory device**: Reduce `view-distance=3` in server.properties
5. **Hot phone**: Reduce `max-players=10`

---

## ⚠️ Troubleshooting

**Server won't start:**
```bash
pkg install php
php -v  # Verify PHP installed
```

**Can't connect from other devices:**
- Make sure devices are on same WiFi
- Your phone's local IP (not localhost)
- Check: `ifconfig | grep inet`

**Web panel can't connect:**
- Verify API server is running (port 8080)
- Enter correct API key from `data/api_key.txt`

---

*Server by Baconrobloxian | Powered by PocketMine-MP*
