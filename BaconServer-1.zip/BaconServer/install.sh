#!/bin/bash
echo "======================================"
echo "   BaconServer - Cai dat tu dong"
echo "   Admin: baconrobloxian"
echo "======================================"
echo ""

# Cap nhat Termux
echo "[1/6] Cap nhat Termux..."
pkg update -y && pkg upgrade -y

# Cai cac goi can thiet
echo "[2/6] Cai PHP va cac cong cu..."
pkg install php curl wget unzip -y

# Tao thu muc server
echo "[3/6] Tao thu muc server..."
mkdir -p ~/mcserver/plugins
mkdir -p ~/mcserver/resource_packs
mkdir -p ~/mcserver/worlds

# Tai PocketMine-MP
echo "[4/6] Tai PocketMine-MP..."
curl -L https://github.com/pmmp/PocketMine-MP/releases/latest/download/PocketMine-MP.phar -o ~/mcserver/PocketMine-MP.phar

# Copy file cau hinh
echo "[5/6] Ap dung cau hinh..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "$SCRIPT_DIR/server.properties" ~/mcserver/server.properties
cp "$SCRIPT_DIR/ops.txt" ~/mcserver/ops.txt
cp "$SCRIPT_DIR/permissions.json" ~/mcserver/permissions.json

# Tao file khoi dong
echo "[6/6] Tao file khoi dong..."
cat > ~/mcserver/start.sh << 'STARTEOF'
#!/bin/bash
cd ~/mcserver
echo "=== BaconServer dang khoi dong ==="
echo "Admin: baconrobloxian | Max: 5 nguoi | Port: 19132"
echo "De dung server: go lenh 'stop' trong console"
echo "=================================="
php PocketMine-MP.phar --no-wizard
STARTEOF
chmod +x ~/mcserver/start.sh

echo ""
echo "======================================"
echo "   Cai dat HOAN THANH!"
echo "======================================"
echo ""
echo "Khoi dong server bang lenh:"
echo "  bash ~/mcserver/start.sh"
echo ""
echo "Ket noi Minecraft PE:"
echo "  IP: IP dien thoai ban (dung lenh: ifconfig)"
echo "  Port: 19132"
echo ""
