# HƯỚNG DẪN CÀI ĐẶT BACONSERVER

## Các file trong gói:
| File | Mô tả |
|------|-------|
| install.sh | Script cài tự động (chạy cái này trước) |
| server.properties | Cấu hình server |
| ops.txt | Danh sách admin |
| permissions.json | Phân quyền chi tiết |

---

## CÁCH CÀI (3 bước):

### Bước 1: Chuyển file vào Termux
Copy toàn bộ folder BaconServer vào thư mục home (~/) trong Termux

### Bước 2: Chạy cài đặt
```bash
cd ~/BaconServer
bash install.sh
```

### Bước 3: Khởi động server
```bash
bash ~/mcserver/start.sh
```

---

## LỆNH ADMIN TRONG CONSOLE SERVER:

| Lệnh | Tác dụng |
|------|----------|
| `op <tên>` | Cấp quyền sub-admin cho người chơi |
| `deop <tên>` | Xóa quyền sub-admin |
| `kick <tên> [lý do]` | Kick người chơi |
| `ban <tên>` | Cấm người chơi vĩnh viễn |
| `pardon <tên>` | Gỡ lệnh cấm |
| `list` | Xem danh sách người đang online |
| `gamemode <mode> <tên>` | Đổi chế độ chơi |
| `give <tên> <item>` | Cho vật phẩm |
| `tp <tên1> <tên2>` | Dịch chuyển người chơi |
| `stop` | Tắt server an toàn |

## PHÂN QUYỀN:
- **baconrobloxian** (level 4): Quyền tối cao, không ai có thể ban/kick
- **Sub-admin** (level 2): Có thể kick, KHÔNG thể ban hoặc op người khác
- **Thành viên** (level 1): Người chơi bình thường

---

## CÀI PLUGIN CHỐNG HACK:
Vào https://poggit.pmmp.io tìm và tải:
- **NoCheatPlus** → chống fly, speed, killaura
- **AntiCheat** → phát hiện hack tool

Copy file .phar vào: `~/mcserver/plugins/`
Khởi động lại server để kích hoạt.

## CÀI RESOURCE PACK / SHADER:
1. Đặt file .mcpack hoặc .zip vào `~/mcserver/resource_packs/`
2. Trong server.properties đổi: `resource-pack-required=true`
3. Người chơi sẽ tự động nhận pack khi vào server

---

## MỞ IP CÔNG KHAI (bạn bè ngoài mạng vào được):
```bash
wget https://github.com/playit-cloud/playit-agent/releases/latest/download/playit-linux-aarch64 -O playit
chmod +x playit
./playit
```
Làm theo hướng dẫn → nhận IP công khai miễn phí → chia sẻ IP đó cho bạn bè.

---

## KẾT NỐI VÀO SERVER:
Minecraft PE → Chơi → Máy chủ → Thêm máy chủ
- **Địa chỉ:** IP điện thoại bạn (hoặc IP từ playit.gg)
- **Cổng:** 19132
